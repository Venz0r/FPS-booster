FPS BOOSTER PRO — ROBLOX EDITION
=================================

Содержимое архива:
- FPS_BOOSTER_PRO.py : основная программа
- requirements.txt  : зависимость Python
- START.bat          : запуск программы в Windows
- README.txt         : эта инструкция

Установка:
1. Установи Python 3 с сайта https://www.python.org/downloads/
2. При установке Python отметь "Add Python to PATH".
3. Дважды нажми START.bat.
   При первом запуске скрипт установит psutil, если он отсутствует.

Запуск вручную:
    py -m pip install -r requirements.txt
    py FPS_BOOSTER_PRO.py

Возможности:
- Мониторинг CPU и RAM.
- Определение CPU, GPU, RAM и типа диска (если Windows сообщает данные).
- Поиск и запуск RobloxPlayerBeta.exe.
- Попытка установить Roblox приоритет Above Normal.
- SMART CLEANUP: предлагает закрыть только выбранные известные приложения
  текущего пользователя (Chrome, Edge, Firefox, Discord, Spotify, Telegram,
  Steam, Epic Games Launcher).
- Очистка файлов TEMP старше 7 дней с подтверждением.

Важные ограничения:
- Программа не гарантирует увеличение FPS.
- SMART CLEANUP не отключает службы Windows, антивирус, драйверы,
  неизвестные процессы или сам Roblox.
- Закрытие браузера и других приложений может привести к потере
  несохранённых данных. Сохрани работу перед закрытием.
- Не запускай программу от имени администратора без необходимости.
