import os
import glob
import time
import platform
import subprocess
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

import psutil

BG = "#101522"
PANEL = "#1a2334"
GREEN = "#00e6a0"
WHITE = "#edf2fa"
MUTED = "#8b9bb4"
ORANGE = "#ffbd59"

# Only these familiar user applications can be offered for closing.
# Windows/system processes and unknown applications are never terminated.
SAFE_TO_CLOSE = {
    "chrome.exe", "msedge.exe", "firefox.exe",
    "discord.exe", "spotify.exe", "telegram.exe",
    "steam.exe", "epicgameslauncher.exe"
}


class FPSBoosterPro:
    def __init__(self, root):
        self.root = root
        self.root.title("FPS BOOSTER PRO")
        self.root.geometry("760x790")
        self.root.minsize(700, 700)
        self.root.configure(bg=BG)

        self.game_path = self.find_roblox()
        self.cpu_samples = {}
        self.cleanup_window = None

        self.setup_style()
        self.create_ui()
        self.detect_hardware()
        self.update_monitor()

    def setup_style(self):
        style = ttk.Style()
        style.theme_use("clam")
        style.configure(
            "TProgressbar",
            troughcolor="#29344a",
            background=GREEN,
            thickness=12
        )

    def create_ui(self):
        header = tk.Frame(self.root, bg=BG)
        header.pack(fill="x", padx=25, pady=(18, 5))

        tk.Label(
            header, text="FPS BOOSTER PRO",
            font=("Segoe UI", 26, "bold"),
            fg=GREEN, bg=BG
        ).pack(side="left")

        tk.Label(
            header, text="ROBLOX EDITION",
            font=("Segoe UI", 10, "bold"),
            fg=MUTED, bg=BG
        ).pack(side="right", pady=12)

        tk.Label(
            self.root,
            text="Безопасный мониторинг и подготовка компьютера к игре",
            font=("Segoe UI", 10), fg=MUTED, bg=BG
        ).pack(anchor="w", padx=28)

        self.section("ХАРАКТЕРИСТИКИ КОМПЬЮТЕРА")
        hardware = tk.Frame(self.root, bg=PANEL, padx=18, pady=10)
        hardware.pack(fill="x", padx=25, pady=5)

        self.cpu_info = self.make_label(hardware, "CPU: Определение...")
        self.gpu_info = self.make_label(hardware, "GPU: Определение...")
        self.ram_info = self.make_label(hardware, "RAM: Определение...")
        self.disk_info = self.make_label(hardware, "Диск: Определение...")
        self.os_info = self.make_label(hardware, "OS: Определение...")

        self.section("МОНИТОРИНГ В РЕАЛЬНОМ ВРЕМЕНИ")
        monitor = tk.Frame(self.root, bg=PANEL, padx=18, pady=12)
        monitor.pack(fill="x", padx=25, pady=5)

        self.cpu_value = tk.Label(
            monitor, text="CPU: измерение...",
            fg=WHITE, bg=PANEL, font=("Segoe UI", 11, "bold")
        )
        self.cpu_value.pack(anchor="w")
        self.cpu_bar = ttk.Progressbar(monitor, maximum=100, length=660)
        self.cpu_bar.pack(fill="x", pady=(3, 12))

        self.ram_value = tk.Label(
            monitor, text="RAM: измерение...",
            fg=WHITE, bg=PANEL, font=("Segoe UI", 11, "bold")
        )
        self.ram_value.pack(anchor="w")
        self.ram_bar = ttk.Progressbar(monitor, maximum=100, length=660)
        self.ram_bar.pack(fill="x", pady=(3, 5))

        self.section("ИГРОВОЙ РЕЖИМ")
        game_panel = tk.Frame(self.root, bg=PANEL, padx=18, pady=12)
        game_panel.pack(fill="x", padx=25, pady=5)

        self.game_label = tk.Label(
            game_panel,
            text=self.game_path or "Roblox не найден — выбери RobloxPlayerBeta.exe",
            fg=GREEN if self.game_path else ORANGE,
            bg=PANEL, font=("Segoe UI", 9), wraplength=650
        )
        self.game_label.pack(anchor="w", pady=5)

        buttons = tk.Frame(game_panel, bg=PANEL)
        buttons.pack(fill="x", pady=5)

        tk.Button(
            buttons, text="ВЫБРАТЬ ИГРУ",
            command=self.select_game, bg="#293750", fg=WHITE,
            font=("Segoe UI", 9, "bold"), relief="flat",
            cursor="hand2", padx=12, pady=9
        ).pack(side="left", padx=(0, 8))

        tk.Button(
            buttons, text="▶ ЗАПУСТИТЬ ROBLOX + BOOST",
            command=self.start_game, bg="#00b982", fg="#071b16",
            font=("Segoe UI", 10, "bold"), relief="flat",
            cursor="hand2", padx=14, pady=9
        ).pack(side="left")

        self.status = tk.Label(
            game_panel, text="STATUS: READY",
            fg=GREEN, bg=PANEL, font=("Segoe UI", 10, "bold")
        )
        self.status.pack(anchor="w", pady=5)

        self.section("ОБСЛУЖИВАНИЕ")
        tools = tk.Frame(self.root, bg=PANEL, padx=15, pady=12)
        tools.pack(fill="x", padx=25, pady=5)

        tk.Button(
            tools, text="SMART CLEANUP — ПРОВЕРИТЬ ПРИЛОЖЕНИЯ",
            command=self.show_smart_cleanup,
            bg="#293750", fg=WHITE,
            font=("Segoe UI", 10, "bold"), relief="flat",
            cursor="hand2", pady=10
        ).pack(fill="x")

        tk.Label(
            tools,
            text="Закрываются только выбранные знакомые приложения. "
                 "Перед закрытием сохраняй документы.",
            bg=PANEL, fg=MUTED, font=("Segoe UI", 8),
            wraplength=650
        ).pack(anchor="w", pady=(7, 0))

        tk.Button(
            tools, text="ОЧИСТИТЬ СТАРЫЕ ВРЕМЕННЫЕ ФАЙЛЫ",
            command=self.clean_temp,
            bg="#293750", fg=WHITE,
            font=("Segoe UI", 9, "bold"), relief="flat",
            cursor="hand2", pady=8
        ).pack(fill="x", pady=(9, 0))

        tk.Label(
            self.root,
            text="Не отключает службы Windows, антивирус или драйверы. "
                 "Прирост FPS не гарантируется.",
            bg=BG, fg=MUTED, font=("Segoe UI", 8),
            wraplength=700
        ).pack(side="bottom", pady=10)

    def section(self, title):
        tk.Label(
            self.root, text=title, bg=BG, fg=GREEN,
            font=("Segoe UI", 10, "bold")
        ).pack(anchor="w", padx=28, pady=(12, 3))

    @staticmethod
    def make_label(parent, text):
        label = tk.Label(
            parent, text=text, bg=PANEL, fg=WHITE,
            font=("Segoe UI", 9), anchor="w"
        )
        label.pack(fill="x", pady=2)
        return label

    def run_powershell(self, command):
        try:
            result = subprocess.run(
                ["powershell", "-NoProfile", "-Command", command],
                capture_output=True, text=True, timeout=10,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0)
            )
            return result.stdout.strip()
        except Exception:
            return ""

    def detect_hardware(self):
        cpu = platform.processor() or "Не определён"
        detected_cpu = self.run_powershell(
            "(Get-CimInstance Win32_Processor | "
            "Select-Object -First 1 -ExpandProperty Name)"
        )
        if detected_cpu:
            cpu = detected_cpu.splitlines()[0]

        gpu = self.run_powershell(
            "(Get-CimInstance Win32_VideoController | "
            "Select-Object -First 1 -ExpandProperty Name)"
        ) or "Не удалось определить"

        disk = self.run_powershell(
            "(Get-PhysicalDisk | Select-Object -First 1 "
            "-ExpandProperty MediaType)"
        ) or "Не удалось определить"

        ram = psutil.virtual_memory().total / (1024 ** 3)

        self.cpu_info.config(text=f"CPU: {cpu}")
        self.gpu_info.config(text=f"GPU: {gpu.splitlines()[0]}")
        self.ram_info.config(text=f"RAM: {ram:.1f} GB")
        self.disk_info.config(text=f"Диск: {disk.splitlines()[0]}")
        self.os_info.config(
            text=f"OS: {platform.system()} {platform.release()}"
        )

    @staticmethod
    def find_roblox():
        local = os.environ.get("LOCALAPPDATA", "")
        if not local:
            return None
        pattern = os.path.join(
            local, "Roblox", "Versions", "*", "RobloxPlayerBeta.exe"
        )
        matches = glob.glob(pattern)
        return max(matches, key=os.path.getmtime) if matches else None

    def select_game(self):
        path = filedialog.askopenfilename(
            title="Выбери RobloxPlayerBeta.exe",
            filetypes=[("Исполняемые файлы", "*.exe")]
        )
        if path:
            self.game_path = path
            self.game_label.config(text=path, fg=GREEN)

    def start_game(self):
        if not self.game_path or not os.path.isfile(self.game_path):
            messagebox.showwarning(
                "FPS BOOSTER PRO",
                "Roblox не найден. Выбери RobloxPlayerBeta.exe."
            )
            return
        try:
            subprocess.Popen(
                [self.game_path],
                cwd=os.path.dirname(self.game_path)
            )
            self.status.config(
                text="STATUS: ИЩУ ПРОЦЕСС ROBLOX...",
                fg=ORANGE
            )
            self.root.after(2500, self.apply_boost)
        except Exception as error:
            messagebox.showerror("Ошибка запуска", str(error))

    def apply_boost(self, attempts=0):
        found = False
        for proc in psutil.process_iter(["pid", "name"]):
            try:
                if (proc.info["name"] or "").lower() == "robloxplayerbeta.exe":
                    psutil.Process(proc.info["pid"]).nice(
                        psutil.ABOVE_NORMAL_PRIORITY_CLASS
                    )
                    found = True
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue

        if found:
            self.status.config(
                text="STATUS: ROBLOX — ПРИОРИТЕТ ABOVE NORMAL",
                fg=GREEN
            )
        elif attempts < 8:
            self.status.config(
                text="STATUS: ОЖИДАНИЕ ЗАПУСКА ROBLOX...",
                fg=ORANGE
            )
            self.root.after(2500, lambda: self.apply_boost(attempts + 1))
        else:
            self.status.config(
                text="STATUS: НЕ УДАЛОСЬ НАЙТИ ПРОЦЕСС ROBLOX",
                fg=ORANGE
            )

    def update_monitor(self):
        cpu = psutil.cpu_percent(interval=None)
        ram = psutil.virtual_memory()

        self.cpu_value.config(text=f"CPU: {cpu:.1f}%")
        self.ram_value.config(
            text=f"RAM: {ram.percent:.1f}% "
                 f"({ram.used / (1024**3):.1f} / "
                 f"{ram.total / (1024**3):.1f} GB)"
        )
        self.cpu_bar["value"] = cpu
        self.ram_bar["value"] = ram.percent
        self.root.after(1500, self.update_monitor)

    def get_process_list(self):
        current_user = psutil.Process().username()
        results = []

        # Prime CPU counters; the next read will contain a useful interval.
        for proc in psutil.process_iter(
            ["pid", "name", "username", "memory_info"]
        ):
            try:
                name = (proc.info["name"] or "").lower()
                if name not in SAFE_TO_CLOSE:
                    continue
                if proc.info["username"] != current_user:
                    continue
                p = psutil.Process(proc.info["pid"])
                p.cpu_percent(interval=None)
                results.append({
                    "pid": p.pid,
                    "name": p.name(),
                    "memory": p.memory_info().rss / (1024 ** 2),
                    "process": p
                })
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue

        time.sleep(0.25)

        for item in results:
            try:
                item["cpu"] = psutil.Process(item["pid"]).cpu_percent(
                    interval=None
                )
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                item["cpu"] = 0.0

        return sorted(
            results,
            key=lambda x: x["memory"],
            reverse=True
        )

    def show_smart_cleanup(self):
        if self.cleanup_window and self.cleanup_window.winfo_exists():
            self.cleanup_window.lift()
            return

        window = tk.Toplevel(self.root)
        self.cleanup_window = window
        window.title("SMART CLEANUP")
        window.geometry("650x570")
        window.configure(bg=BG)

        tk.Label(
            window, text="SMART CLEANUP",
            font=("Segoe UI", 21, "bold"),
            fg=GREEN, bg=BG
        ).pack(pady=(15, 5))

        tk.Label(
            window,
            text="Отмечай только те приложения, которые сейчас не нужны.",
            fg=WHITE, bg=BG, font=("Segoe UI", 9)
        ).pack(pady=(0, 10))

        holder = tk.Frame(window, bg=PANEL)
        holder.pack(fill="both", expand=True, padx=15, pady=5)

        canvas = tk.Canvas(holder, bg=PANEL, highlightthickness=0)
        scrollbar = ttk.Scrollbar(
            holder, orient="vertical", command=canvas.yview
        )
        inner = tk.Frame(canvas, bg=PANEL)

        inner.bind(
            "<Configure>",
            lambda event: canvas.configure(
                scrollregion=canvas.bbox("all")
            )
        )
        canvas.create_window((0, 0), window=inner, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        tk.Label(
            inner,
            text="Имя приложения                         CPU       RAM",
            bg=PANEL, fg=MUTED, font=("Consolas", 9)
        ).pack(anchor="w", padx=10, pady=8)

        selected = []
        processes = self.get_process_list()

        if not processes:
            tk.Label(
                inner,
                text="Подходящие приложения не найдены.",
                bg=PANEL, fg=WHITE
            ).pack(padx=10, pady=15)
        else:
            for item in processes:
                var = tk.BooleanVar(value=False)
                selected.append((item["pid"], item["name"], var))
                row = tk.Frame(inner, bg=PANEL)
                row.pack(fill="x", padx=8, pady=4)

                label = (
                    f'{item["name"]:<25} '
                    f'{item["cpu"]:>5.1f}%  '
                    f'{item["memory"]:>7.0f} MB'
                )
                tk.Checkbutton(
                    row, text=label, variable=var,
                    bg=PANEL, fg=WHITE, selectcolor=BG,
                    activebackground=PANEL,
                    activeforeground=GREEN,
                    font=("Consolas", 9), anchor="w"
                ).pack(fill="x")

        def close_selected():
            chosen = [
                (pid, name) for pid, name, var in selected if var.get()
            ]
            if not chosen:
                messagebox.showinfo(
                    "SMART CLEANUP", "Сначала выбери приложение.",
                    parent=window
                )
                return

            names = "\n".join(name for _, name in chosen)
            if not messagebox.askyesno(
                "Подтверждение",
                "Закрыть выбранные приложения?\n"
                "Несохранённые данные могут быть потеряны.\n\n" + names,
                parent=window
            ):
                return

            requested = 0
            for pid, expected_name in chosen:
                try:
                    proc = psutil.Process(pid)
                    # Recheck PID, process name, user and allowlist.
                    if proc.name().lower() != expected_name.lower():
                        continue
                    if proc.name().lower() not in SAFE_TO_CLOSE:
                        continue
                    if proc.username() != psutil.Process().username():
                        continue
                    proc.terminate()
                    requested += 1
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue

            messagebox.showinfo(
                "SMART CLEANUP",
                f"Запросов на закрытие: {requested}\n"
                "Некоторые приложения могут закрываться несколько секунд.",
                parent=window
            )
            window.destroy()

        tk.Button(
            window, text="ЗАКРЫТЬ ВЫБРАННЫЕ ПРИЛОЖЕНИЯ",
            command=close_selected, bg="#00b982", fg="#071b16",
            font=("Segoe UI", 10, "bold"), relief="flat",
            pady=11, cursor="hand2"
        ).pack(fill="x", padx=20, pady=12)

    def clean_temp(self):
        temp = os.environ.get("TEMP")
        if not temp or not os.path.isdir(temp):
            messagebox.showerror(
                "Ошибка", "Папка временных файлов не найдена."
            )
            return

        if not messagebox.askyesno(
            "Очистка временных файлов",
            "Удалить файлы из TEMP старше 7 дней?\n"
            "Занятые файлы будут пропущены."
        ):
            return

        cutoff = time.time() - 7 * 24 * 60 * 60
        deleted = 0
        skipped = 0

        for folder, dirs, files in os.walk(temp):
            for filename in files:
                path = os.path.join(folder, filename)
                try:
                    if os.path.getmtime(path) < cutoff:
                        os.remove(path)
                        deleted += 1
                except OSError:
                    skipped += 1

        messagebox.showinfo(
            "FPS BOOSTER PRO",
            f"Удалено файлов: {deleted}\nПропущено: {skipped}"
        )


if __name__ == "__main__":
    if platform.system() != "Windows":
        print("FPS BOOSTER PRO предназначен для Windows 10/11.")
    else:
        psutil.cpu_percent(interval=None)
        root = tk.Tk()
        app = FPSBoosterPro(root)
        root.mainloop()
