@echo off
title FPS BOOSTER PRO
cd /d "%~dp0"
py -c "import psutil" >nul 2>&1
if errorlevel 1 (
    echo Installing required library: psutil
    py -m pip install -r requirements.txt
    if errorlevel 1 (
        echo.
        echo Installation failed. Check your Python installation and internet connection.
        pause
        exit /b 1
    )
)
py FPS_BOOSTER_PRO.py
if errorlevel 1 (
    echo.
    echo The program could not start. Check the error above.
    pause
)
